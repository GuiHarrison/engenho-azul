<svg version="1.1"
	 id="Layer_1" xmlns:cc="http://creativecommons.org/ns#" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd" xmlns:svg="http://www.w3.org/2000/svg"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="35px" height="35px"
	 viewBox="0 0 512 512" enable-background="new 0 0 512 512" xml:space="preserve">
<path fill="#FFFFFF" d="M448,0H64C28.654,0,0,28.654,0,64v384c0,35.347,28.654,64,64,64h384c35.346,0,64-28.653,64-64V64
	C512,28.654,483.346,0,448,0z M146.813,436.631h-85.76V178.668h85.76V436.631z M103.932,143.428h-0.555
	C74.588,143.428,56,123.606,56,98.854c0-25.284,19.171-44.574,48.513-44.574c29.323,0,47.38,19.29,47.935,44.574
	C152.447,123.606,133.834,143.428,103.932,143.428z M456,436.631h-85.742V298.61c0-34.663-12.424-58.328-43.436-58.328
	c-23.688,0-37.806,15.953-43.992,31.353c-2.273,5.512-2.828,13.22-2.828,20.932v144.064h-85.737c0,0,1.137-233.766,0-257.963h85.738
	v36.523c11.409-17.572,31.786-42.589,77.276-42.589c56.415,0,98.721,36.861,98.721,116.098V436.631z"/>
</svg>
