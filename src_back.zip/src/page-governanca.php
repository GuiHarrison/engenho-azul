<?php get_header(); ?>

	<main role="main">
		<!-- section -->
		<section>

		<?php if (have_posts()): while (have_posts()) : the_post(); ?>

			<!-- article -->
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

					<div class="cadaSomos">
						<div class="<?php if( !wp_is_mobile()) {echo 'imagemQuemSomos';} else {echo 'flamula';} ?>">
							<h2>DNA Precon</h2>
						</div>
						<?php the_field('dna_precon'); ?>
					</div>

					<div class="cadaSomos">
						<div class="<?php if( !wp_is_mobile()) {echo 'imagemQuemSomos';} else {echo 'flamula';} ?>">
							<h2>Precon Engenharia</h2>
						</div>
						<?php the_field('precon_engenharia'); ?>
					</div>

					<div class="cadaSomos">
						<div class="<?php if( !wp_is_mobile()) {echo 'imagemQuemSomos';} else {echo 'flamula';} ?>">
							<h2>Estrutura Pré-Fabricada</h2>
						</div>
						<?php the_field('estrutura_pre-fabricada'); ?>
					</div>

					<div class="cadaSomos">
						<div class="<?php if( !wp_is_mobile()) {echo 'imagemQuemSomos';} else {echo 'flamula';} ?>">
							<h2>Solução Habitacional</h2>
						</div>
						<?php the_field('habitação_habitacional'); ?>
					</div>


				<br class="clear">

				<?php edit_post_link(); ?>

			</article>
			<!-- /article -->

		<?php endwhile; ?>

		<?php else: ?>

			<!-- article -->
			<article>

				<h2><?php _e( 'Sorry, nothing to display.', 'html5blank' ); ?></h2>

			</article>
			<!-- /article -->

		<?php endif; ?>

		</section>
		<!-- /section -->
	</main>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
