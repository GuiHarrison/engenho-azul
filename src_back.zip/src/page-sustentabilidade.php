<?php get_header(); ?>

	<main role="main">
		<!-- section -->
		<section>

		<?php if (have_posts()): while (have_posts()) : the_post(); ?>

			<!-- article -->
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<?php
					echo '<div class="pilares" id="pilar_1"><h2 class="botaoGrande">Pilar 1</h2>';
						the_field('pilar_1');
					echo '</div>';

					echo '<div class="pilares" id="pilar_2"><h2 class="botaoGrande">Pilar 2</h2>';
						the_field('pilar_2');
					echo '</div>';

					echo '<div class="pilares" id="pilar_3"><h2 class="botaoGrande">Pilar 3</h2>';
						the_field('pilar_3');
					echo '</div>';

				?>

				<br class="clear">

				<?php edit_post_link(); ?>

			</article>
			<!-- /article -->

		<?php endwhile; ?>

		<?php else: ?>

			<!-- article -->
			<article>

				<h2><?php _e( 'Sorry, nothing to display.', 'html5blank' ); ?></h2>

			</article>
			<!-- /article -->

		<?php endif; ?>

		</section>
		<!-- /section -->
	</main>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
