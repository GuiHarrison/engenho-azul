<?php
    define('HTML5_DEBUG', <%= is_debug %>);
?>