
<svg version="1.1"
	 id="Layer_1" xmlns:cc="http://creativecommons.org/ns#" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd" xmlns:svg="http://www.w3.org/2000/svg"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="35px" height="35px"
	 viewBox="0 0 512 512" enable-background="new 0 0 512 512" xml:space="preserve">
<path fill="#FFFFFF" d="M448,0H64C28.654,0,0,28.654,0,64v384c0,35.347,28.654,64,64,64h384c35.346,0,64-28.653,64-64V64
	C512,28.654,483.346,0,448,0z M359.859,122.409l-37.655,0.011c-29.515,0-35.235,14.031-35.235,34.62v45.395h70.413l-9.17,71.102
	h-61.244V456h-73.427V273.538h-61.4v-71.103h61.402v-52.437c0-60.852,37.162-93.998,91.45-93.998c26.01,0,48.357,1.934,54.867,2.808
	V122.409z"/>
</svg>
